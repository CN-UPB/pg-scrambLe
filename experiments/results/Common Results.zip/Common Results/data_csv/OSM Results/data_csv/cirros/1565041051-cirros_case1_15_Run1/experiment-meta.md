Experiment Start Time 1565040991
Instantiation Start Time 1565041051
Instantiation End Time 1565041082
Termination Start Time 1565041159
Termination End Time 1565041160
Experiment End Time 1565041220

http://osmmano.cs.upb.de:9000/interactive?host=osmmano.cs.upb.de&after=1565040991&before=1565041220&start_time=1565040991&ns_inst_time=1565041051&ns_inst_end_time=1565041082&ns_term_start_time=1565041159&ns_term_end_time=1565041160&end_time=1565041220&exp_description=cirros_case1_15_Run1